extern void test_IsDescendents(void);
extern void testTraverseWithoutStackOrRecursion(void);
extern void testSwapTree(void);
extern void testTraverseWithQueue(void);

void  main(void)
{
	//test_IsDescendents();
	//testTraverseWithoutStackOrRecursion();
	//testSwapTree();
	testTraverseWithQueue();
}