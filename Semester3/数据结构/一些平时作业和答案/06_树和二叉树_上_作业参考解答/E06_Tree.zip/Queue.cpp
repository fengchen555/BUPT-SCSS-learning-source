#include"Globals.h"
#include<stdlib.h>
#include<stdio.h>

Status InitQueue(SqQueue *Q) {
	Q->base = (QElemType *)malloc(MAXQSIZE * sizeof(QElemType));
	if (!Q->base)
		return ERROR_OVERFLOW;
	Q->empty = true;
	Q->front = Q->rear = 0;
	return OK;
}

int QueueLength(SqQueue *Q) {
	int len = (Q->rear - Q->front + MAXQSIZE) % MAXQSIZE;
	if (len == 0 && !Q->empty) {
		len = MAXQSIZE;
	}
	return len;
}

Status EnQueue(SqQueue *Q, QElemType e) {
	if (!Q->empty && Q->front == Q->rear)
		return ERROR_OVERFLOW;//�������ˣ��޷�����Ԫ��
	Q->base[Q->rear] = e;
	Q->rear = (Q->rear + 1) % MAXQSIZE;
	if (Q->rear == Q->front)
		Q->empty = false;//����Ԫ�غ󣬶�������
	return OK;
}

Status DeQueue(SqQueue *Q, QElemType *e) {
	if (Q->empty && Q->front == Q->rear)
		return ERROR_EMPTY;//���п��ˣ��޷�ɾ��Ԫ��
	*e = Q->base[Q->front];
	Q->front = (Q->front + 1) % MAXQSIZE;
	if (Q->rear == Q->front)
		Q->empty = true;//ɾ��Ԫ�غ󣬶��п���
	return OK;
}

Status DestroyQueue(SqQueue *Q) {
	if (!Q->base) return ERROR;
	free(Q->base);
	Q->front = Q->rear = -1;
	return OK;
}

Status PrintQueue(SqQueue *Q) {
	int pos = Q->front, len = QueueLength(Q), i = 0;

	printf("SqQueue:");
	for (i = 0; i < len; i++) {
		printf("%d\t", Q->base[pos]);
		pos = (pos + 1) % MAXQSIZE;
	}
	printf("\n");
	return OK;
}
