/*P42, 6.33*/
bool IsDescendents(int v, int u, int R[], int L[])
{//if u is a descendent of v, then return true
	bool bret = false;

	if (v == 0)
		return bret;
	if (v == u)
		return true;
	bret = IsDescendents(L[v], u, R, L) || IsDescendents(R[v], u, R, L);
	return bret;
}

void test_IsDescendents(void) {
	int L1[] = {0, 2,4,6,8,10,12,14,0,0, 0,0,0,0,0,0 }, R1[] = {0, 3, 5, 7, 9, 11, 13, 15, 0, 0, 0, 0, 0, 0, 0, 0 };
	bool b = false;

	b = IsDescendents(1, 15, R1, L1);//true
	b = IsDescendents(2, 14, R1, L1);//false
	b = IsDescendents(5, 6, R1, L1);//false
	b = IsDescendents(9, 4, R1, L1);//false
	b = IsDescendents(3, 13, R1, L1);//true
}