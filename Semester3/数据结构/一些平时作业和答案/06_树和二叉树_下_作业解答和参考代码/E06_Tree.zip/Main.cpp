extern void test_IsDescendents(void);
extern void testTraverseWithoutStackOrRecursion(void);
extern void testSwapTree(void);
extern void testTraverseWithQueue(void);
extern void testFindMaxComnPath(void);
extern void testPrintAllEdges(void);
extern void testCTDepth(void);
void  main(void)
{
	//test_IsDescendents();
	//testTraverseWithoutStackOrRecursion();
	//testSwapTree();
	//testTraverseWithQueue();
	//testFindMaxComnPath();
	//testPrintAllEdges();
	testCTDepth();
}