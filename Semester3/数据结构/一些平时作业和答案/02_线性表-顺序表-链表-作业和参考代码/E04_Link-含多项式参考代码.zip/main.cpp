
extern int testList(void);
extern void testPoly(void);

int main(void)
{
	//testList();
	testPoly();
	return 0;
}