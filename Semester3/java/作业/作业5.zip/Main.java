public class Main {//主函数
    public static void main(String[] args) {
        //实例化四个Student
        Student a = new Student();
        Student b = new Student();
        Student c = new Student();
        Student d = new Student();
        //赋值
        a.setScore(150);
        b.setScore(60);
        c.setScore(90);
        d.setScore(100);
        //实例化一个关于student的DataSet
        DataSet studentSet = new DataSet();
        studentSet.add(a);
        studentSet.add(b);
        studentSet.add(c);
        studentSet.add(d);
        //输出这一组对象的平均值，和其中测量值最大的一个对象
        System.out.println("Student组的 Maximum ："+studentSet.getMaximum());
        System.out.println("Student组的 Average ："+studentSet.getAverage());
        //------------------------------HumanSet----------------------------------------------------//
        //实例化四个Human
        Human a1 = new Human();
        Human b1 = new Human();
        Human c1 = new Human();
        Human d1 = new Human();
        //初始化 赋值
        a1.setAge(50);
        b1.setAge(34);
        c1.setAge(20);
        d1.setAge(16);
        //实现 humanSet
        DataSet humanSet = new DataSet();
        humanSet.add(a1);
        humanSet.add(b1);
        humanSet.add(c1);
        humanSet.add(d1);
        //输出这一组对象的平均值，和其中测量值最大的一个对象
        System.out.println("Human组的 Maximum ："+humanSet.getMaximum());
        System.out.println("Human组的 Average ："+humanSet.getAverage());




    }
}
