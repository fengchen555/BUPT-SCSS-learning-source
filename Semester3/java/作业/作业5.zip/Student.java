public class Student implements Data{
    double score;//分数
    public void setScore( double score){
        this.score = score;
    }

    @Override//写接口
    public double getData() {
        return score;
    }

}
