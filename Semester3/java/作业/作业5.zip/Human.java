public class Human  implements Data {
    double age;//年龄
    public void setAge( double age){
        this.age = age;
    }

    @Override//实现接口
    public double getData() {
        return age;
    }
}
