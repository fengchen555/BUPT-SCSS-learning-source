public interface Data {//实现接口Data
    public double getData();
}
