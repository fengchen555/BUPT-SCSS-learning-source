import java.util.Scanner;

public class hk2 {
    public static void main(String[] args) {
        int n;
        double f;
        String name;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter an integer:");
        n = in.nextInt();
        System.out.print("Enter a floating point number:");
        f = in.nextDouble();
        System.out.print("Enter your name:");
        name = in.next();
        System.out.println("Hi! "+name+", the sum of "+ n +" and "+ f +" is "+(n+f));

    }
}
