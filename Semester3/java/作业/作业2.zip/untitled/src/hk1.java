
public class hk1 {
    public static void main(String[] args) {
        final int  num = 9;
        System.out.println("*   |   1   2   3   4   5   6   7   8   9");
        System.out.println("-----------------------------------------");
        for(int i = 1;i <= num; i++){
            System.out.print(i+"\t|\t");
            for (int j = 1; j <= num;j++){
                System.out.print(i*j+"\t");
            }
            System.out.println();
        }
    }
}
