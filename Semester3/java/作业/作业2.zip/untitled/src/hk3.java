import java.util.Scanner;

public class hk3 {
//    class  boolean ifBinary (int num)
//    {
//        int j = 0;
//        boolean is = true;
//        while(num>0)
//        {
//            j=num%10;
//            if((j != 0)&&(j != 1))
//            {
//                is = false;
//            }
//        }
//        if (is ){
//            return true;
//        }
//        else return  false;
//    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long n;
        System.out.print("Enter a Binary string:");
        n = in.nextLong();
        long m = n;
        boolean isbyte = true;
        long j;
        while(m>0)
        {
            j = m%10;
            if((j != 0)&&(j != 1))
            {
                isbyte = false;
                break;
                }
            m /=10;
        }
        if(isbyte){
            m = n;
            long a = 0;
            int muti = 1;
            while(m!=0){
                a += (m%10)*muti;
                muti *=2;
                m /=10;
            }
            System.out.print("The equivalent decimal number for binary\t" + "\""+n+"\"" +"\tis\t"+ a);
        }
        else System.out.print("Error: Invalid Binary String:\t"+ "\""+n+"\"");


    }
}
