import java.util.Scanner;

public class hk4 {
    public static void main(String[] args) {
        System.out.print("Enter a Hexadecimal string:");
        Scanner in = new Scanner(System.in);
        String s;
        s = in.next();
        char [] s1;
        String [] s2 = new String [10005];
        int len = s.length();
        s1 = s.toCharArray();//对输入的字符串转字符数组
        int j;
//        String[] hexBits = {"0000", "0001", "0010", "0011",
//                "0100", "0101", "0110", "0111",
//                "1000", "1001", "1010", "1011",
//                "1100", "1101", "1110", "1111"};
        for(int i = 0;i < len;i++){
            String temp = Character.toString(s1[i]);
            //System.out.println(temp);
            j = Integer.parseInt(temp,16 );//想利用java本身的类直接对16进制转10进制
            //System.out.println(j);
            s2[i] = Integer.toBinaryString(j);//10进制转2进制字符串
            s2[i]=String.format("%4s", s2[i]).replace(" ","0");//2进制输出4位并进行补0操作

            //System.out.println(j);测试
        }
        System.out.print("The equivalent binary for hexadecimal "+"\""+ s +"\""+"is\t");
        for(int i = 0; i < len;i++){
            System.out.print(s2[i]+"\t");
        }
    }
}
