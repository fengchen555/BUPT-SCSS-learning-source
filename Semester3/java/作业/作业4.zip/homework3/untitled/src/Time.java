import java.util.Date;
public class Time {
    private int hour;
    private int minus;
    String hourSystem = "24";
    String time;//a功能

    public Time(int hour,int minus)
    {
        this.hour = hour;
        this.minus = minus;
    }
    public Time(String hourSystem){
        Date date = new Date();
        this.hour = date.getHours();
        this.minus = date.getMinutes();
        this.hourSystem = hourSystem;
        if(hourSystem == "12"){

            if(hour >= 12){
                time = "PM";
                hour %=12;

            } else time = "AM";
        }
    }
    public Time(int hour,int minus,int hour12)//12进制计时构造函数
    {
        hourSystem = "12";

        if(hour >= 12){
            time = "PM";
        } else time = "AM";

        this.hour = hour % 12;
        this.minus = minus % 60;
    }
    public int getHour(){
        return hour;
    }
    public int getMinus(){
        return minus;
    }

    @Override
    public String toString() {//功能j ：提供toString( )方法用来打印时间，以24小时计时，输出“23：30”；
        // 以12小时计时，输出“00：15AM”，“12：00PM”，“11：59PM”。
        String print = "";
        if(hour < 10){
           print += "0";
        }
        print += hour;
        print +=":";
        if(minus <10 ){
            print += "0";
        }
        print +=minus;
        if(hourSystem =="12") print += time;
        return print;
    }
    public void hourAdd1h(){
        if(hourSystem == "24"){
            hour++;
            hour %= 24;
        } else if(hourSystem == "12"){
            hour++;
            if(hour >=12&&time =="PM"){
               time = "AM";
            } else if (hour >=12&&time =="AM") {
                time = "PM";
            }
            hour %= 12;
        }

    }
    public void hourAddNh(int n){
        if (hourSystem == "12") {
            hour += n;
            if(hour/12 == 1){
                if(time == "PM") time = "AM";
                else time = "PM";
            }
            hour %=12;
        } else {
            hour += n;
            hour %= 24;
        }
    }
    public void minusAdd1min(){
        if (hourSystem == "24") {
            minus++;
            if(minus >= 60){
                minus %= 60;
                hourAdd1h();
            }
        } else {
            minus++;
            if(minus >= 60){
                hourAdd1h();
                minus %= 60;
            }
        }
    }
    public  void minusAddNminus(int n){
        minus +=n;
        hourAddNh(minus/60);
        minus %= 60;
    }

    public static void main(String[] args) {
        Time time1 = new Time(23,59);//功能c 以特定的时间完成构造函数
        System.out.println(time1.toString());
        time1.hourAdd1h();//功能f 提供方法能够将时间增加1小时；
        System.out.println(time1.getHour());//功能d： 能够访问时间的小时数；
        System.out.println(time1.getMinus());//功能e：能够访问时间的分钟数；
        System.out.println(time1.toString());
        time1.minusAdd1min();//功能h 提供方法能够将时间增加1分钟；
        System.out.println(time1.toString());
        time1.hourAddNh(100);//功能g 提供方法能够将时间增加特定的小时；
        System.out.println(time1.toString());
        time1.minusAddNminus(61);//功能i: 提供方法能够将时间增加n分钟；
        System.out.println(time1.toString());
        Time time2 = new Time(23,59,12);
        System.out.println("12h小时制");
        System.out.println(time2.toString());
        System.out.println("hour:"+time2.getHour()+"minus:"+time2.getMinus());
        time2.hourAdd1h();
        System.out.println(time2.toString());
        time2.minusAdd1min();
        System.out.println(time2.toString());
        time2.minusAddNminus(210);
        System.out.println(time2.toString());
        time2.hourAddNh(70);
        System.out.println(time2.toString());
        time2.hourAddNh(12);
        System.out.println(time2.toString());

        Time time3 = new Time("12");//功能b以当前的时间构造对象
        System.out.println(time3.toString());
        Time time4 = new Time("24");//功能b以当前的时间构造对象
        System.out.println(time4.toString());

    }
}