import java.util.Objects;

public class Student extends Human{
    private String score;

    public Student(int year, int month, int day,String score) {
        super(year, month, day);
        this.score = score;
    }

    public String getScore() {
        return score;
    }

    @Override
    public boolean equals(Object obj) {
        if( this == obj ) return true;
        if( obj instanceof Student other ){
            return super.equals(other) && this.score == other.score;
        }
        return false;
    }

    @Override
    public String toString() {
        return super.toString()+"score:"+score;
    }

    @Override
    public int hashCode() {
        return super.hashCode()+score.hashCode();//加上一次hashcode
    }

    public static void main(String[] args) {
        Human student1 = new Student(2002,5,23,"60");

        System.out.println(student1.toString());
        //System.out.println(student1.getScore);报错需要向下转型
        Student student2 = (Student)student1;
        System.out.println("Score:"+student2.getScore());//若要调用子类的自己的函数必须向下转型
        Student student3 = new Student(2003,5,23,"70");
        System.out.println("student3_hashCode:"+student3.hashCode());
        System.out.println("student3_TOString:"+student3);
        Student student4 = student3;
        System.out.println("student3_equal(student1):"+student3.equals(student1));
        System.out.println("student3_equal(student2):"+student3.equals(student2));
        System.out.println("student3_equal(student4):"+student3.equals(student4));
        Human student5 = new Human(2004,5,23);
        Human student6 = new Human(2004,5,23);
        Human student7 = new Human(2005,5,23);
        Human student8 = student5;
        System.out.println(student5);
        System.out.println(student5.hashCode());
        System.out.println("student5_equal(student6):"+student5.equals(student6));
        System.out.println("student5_equal(student7):"+student5.equals(student7));
        System.out.println("student5_equal(student8):"+student5.equals(student8));
        Student student9 = new Student(2003,5,23,"70");
        Student student10 = new Student(2008,5,23,"70");
        System.out.println("student3_equal(student9):"+student3.equals(student9));
        System.out.println("student3_equal(student10):"+student3.equals(student10));

    }
}
