public class Human {
    private int brithYear;
    private int brithMonth;
    private int brithDay;

    public Human(int year,int month,int day) {
        this.brithYear = year;
        this.brithMonth = month;
        this.brithDay = day;
    }

    public int getBrithYear() {
        return brithYear;
    }

    public int getBrithMonth() {
        return brithMonth;
    }

    public int getBrithDay() {
        return brithDay;
    }


    public String toString() {
        return "brithYear : " + brithYear+"\tbrithMonth:"+brithMonth+"\tbrithDay:"+brithDay+"\t";
    }


//    public boolean equals(Object obj) {
//        return super.equals(obj);
//    }
}
