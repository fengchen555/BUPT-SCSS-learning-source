import javax.swing.*;
import java.awt.geom.*;

import java.awt.*;

public class SmileTest1 {
    public static void main(String[] args){
        EventQueue.invokeLater(() ->
        {
            JFrame f = new SmileFrame();
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            f.setTitle("smile Frame");
            f.setVisible(true);
        }); }

}
class SmileFrame extends JFrame {
    public SmileFrame(){
        add(new SmileComponent());
        pack();
    }
}
class SmileComponent extends JComponent {
    public void paintComponent (Graphics g) {
        Graphics2D g1 = (Graphics2D) g;
        int X = 50;
        int Y = 50;
//        double width = 260;
//        double height = 200;
        int radius1 = 40;
        int radius2 = 200;
//        Ellipse2D sCircle1 = new Ellipse2D.Double();
//        Ellipse2D sCircle2 = new Ellipse2D.Double();
//        Ellipse2D bigCircle = new Ellipse2D.Double();
//        bigCircle.set
//        double a = bigCircle.getCenterX();
//        double b = bigCircle.getCenterY();
//        g1.setPaint(Color.YELLOW);
//        g1.fill(bigCircle);
        g1.setColor(Color.YELLOW);
        g1.fillOval(X,Y,radius2,radius2);//先画一个大黄圆
        g1.setColor(Color.BLACK);
        g1.fillOval(X+25,Y+50,radius1,radius1);
        g1.fillOval(X+125,Y+50,radius1,radius1);//画两个眼睛
//        g1.fillOval(X,Y,radius2-10,radius2-10);
        g1.drawArc (X+35, Y+80, 130, 100, 0, -180);//画弧线经过不停地调参。。


    }

    public Dimension getPreferredSize(){
        return new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }

    static final int DEFAULT_WIDTH = 300;
    static final int DEFAULT_HEIGHT = 200;


}


