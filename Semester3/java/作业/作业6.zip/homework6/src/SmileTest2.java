import javax.swing.*;
import java.awt.geom.*;

import java.awt.*;

public class SmileTest2 {
    public static void main(String[] args){
        EventQueue.invokeLater(() ->
        {
            JFrame f = new SmileFrame2();
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            f.setTitle("smile Frame");
            f.setVisible(true);
        }); }

}
class SmileFrame2 extends JFrame {
    public SmileFrame2(){
        add(new SmileComponent2());
        pack();
    }
}
class SmileComponent2 extends JComponent {
    public void paintComponent (Graphics g) {
        Graphics2D g1 = (Graphics2D) g;
        int X = 50;
        int  Y = 50;
        int radius1 = 40;
        int radius2 = 200;
        g1.setColor(Color.yellow);
        g1.fillOval(X,Y,radius2+20,radius2+20);//先画大黄圆
        g1.setColor(Color.black);

        g1.fillOval(X+40,Y+100,radius2-60,radius2-100);
        g1.setColor(Color.yellow);
        g1.fillOval(X+40,Y+100,radius2-60,radius2-120);//先画一个黄圆再拿一个黑圆去覆盖
        g1.setColor(Color.black);
        g1.fillOval(X+50,Y+75,radius1,radius1);//画两个眼睛
        g1.fillOval(X+125,Y+75,radius1,radius1);



    }

    public Dimension getPreferredSize(){
        return new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }

    static final int DEFAULT_WIDTH = 300;
    static final int DEFAULT_HEIGHT = 200;


}



