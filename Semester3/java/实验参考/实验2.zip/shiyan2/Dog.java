public class Dog extends  Pet{
    String body;
    double moneySum = 0;
    int count = 0;


    public Dog(String pname, String oname, double wt,String body) {
        super(pname, oname, wt);
        this.body = body;

    }

    @Override
    public String toString() {
        return body+" dog " +super.toString();
    }

    @Override
    public double visit(int shots) {
        count++;
        if(body == "small") return moneySum = 15+super.visit(shots);
        else if(body == "medium") return moneySum = 15+2.5*shots+super.visit(shots);
        else return moneySum = 15+5*shots+super.visit(shots);
    }

    @Override
    public double avgCost() {
        if(count==0) return  0;
        return moneySum/count;
    }
}
