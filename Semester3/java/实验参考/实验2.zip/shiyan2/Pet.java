import java.text.DecimalFormat;

/** This is a class to define Pet objects. Pets should be compared 
according to their owner's names, ignoring capitalization. Ties
should be broken based on the pet's name, ignoring capitalization.

Your job is to add the necessary data and methods to support the
P3main program, as well as the related classes in this system. Some
required methods are noted below with comments, but these are not the
only things you will need.
*/
public class Pet  implements Comparable<Pet>{

   /** Handy for formatting. */
   private static DecimalFormat money = new DecimalFormat("0.00");

   /* The access specifiers for these variables must not be changed! */

   private String name;
   private String owner;
   private double weight;
   private int count = 0;
   private double moneySum = 0;
   boolean isVisit = false;

   public String getName() {
      return name;
   }

   public String getOwner() {
      return owner;
   }

   public double getWeight() {
      return weight;
   }

   /** Create a Pet object, initializing data members.
    *  @param pname the Pet's name
    *  @param oname the owner's name
    *  @param wt the weight of the pet
    */
   public Pet(String pname, String oname, double wt) {
      this.name = pname;
      this.owner = oname;
      this.weight = wt;
   }

@Override
   public boolean equals(Object obj) {

      if (this == obj) return  true;
      if (obj == null) return  false;

      if(!(obj instanceof Pet)) return  false;

      Pet other = (Pet) obj;




   return (this.name == null ? other.name == null :this.name.equalsIgnoreCase(other.name))&&(this.owner == null ? other.owner == null :this.owner.equalsIgnoreCase(other.owner));


   }

   @Override
   public String toString() {
      return this.name + " (owner " + this.owner + ") " + this.weight
          + " lbs, $" + money.format(this.avgCost()) + " avg cost/visit  ";
   }

   /** The Pet is visiting the vet, and will be charged accordingly.
    *  The base cost for a visit is $85.00, and $30/shot is added.
    *  @param shots the number of shots the pet is getting
    *  @return the entire cost for this particular visit
    */
   public double visit(int shots) {
      this.isVisit = true;
      count++;
      moneySum += 85+shots*30;
      return 85+shots*30;

   }

   /** Determine the average cost per visit for this pet.
    *  @return that cost, or 0 if no visits have occurred yet
    */
   public double avgCost() {
      if(isVisit) return moneySum/count;
      else  return  0;
   }


   @Override
   public int compareTo(Pet o) {
      if(this.owner.compareTo(o.owner) == 0) {
         if(this.name.compareTo(o.name) > 0) return 1;
         else  return 0;
      } else if(this.owner.compareTo(o.owner) > 0) return 1;
      else return 0;
   }
}
