import java.util.Arrays;

/** Class to keep track of client (Pet) information for a Veterinary
    practice. Some methods are sketched for you, but others will need
    to be added in order to implement the Database interface and
    support the P3main program and expected output. You'll also need
    to add the data members.
*/
public class Vet implements Database{
    String who;
    Pet p[] = new Pet[STARTSIZE];
    int size;
    int startSize;
    double sumWeight = 0;

    @Override
    public int size() {
        return size;
    }

    /** Create a veterinary practice.
    * @param startSize the capacity for how
    * many clients they can handle
    * @param who the name of the vet practice
    */
   public Vet(int startSize, String who) {
       this.startSize = startSize;
       this.who = who;
       this.size = 0;
   }

    /** Display the name of the Vet and all the clients, one per line,
     * on the screen. (See sample output for exact format.)
    */
   public void display() {
       System.out.println("Vet Pets R Us client list: ");

       for (int i = 0;i < size;i++){
           System.out.println(p[i]);
       }

   }


    /** Add an item to the database, if there is room.
        You are limited by the initial capacity.
        @param o the object to add (must be a Pet)
        @return true if added, false otherwise
    */
   public boolean add(Object o) {

       if(o == null) return false;
       if(!(o instanceof  Pet))   return false;
       Pet other = (Pet) o;
       p [size++] = other;
       sumWeight += other.getWeight();
       return  true;


   
   }

    /** Delete an item from the database, if it is there,
        maintaining the current ordering of the list.
        @param o the object to delete
        @return the item if one is deleted, null otherwise
    */
   public Object delete(Object o) {
       if(!(o instanceof Pet)) return null;
       else {
           Pet other  = (Pet) o;
           for (int i = 0;i < size;i++){
               if(other.equals(p[i])) {
                   Pet temp = p[i];
                   for(int j = i;j < size-1;j++){
                       p[j] = p[j+1];
                   }
                   sumWeight -= other.getWeight();
                   size--;
                   return  temp;
               }
           }

       }
       return  null;
   
   }

    /** Compute the average weight over all clients.
        @return the average
    */
   public double averageWeight() {
       return sumWeight/size;
   }

    /** Sort the clients. (This is complete.)
     */
   public void sort() {
       for(int i = 0;i < size - 1;i++){
           for(int j = 0; j  < size-1;j++){
               if(p[j].compareTo(p[j+1]) == 1){
                   Pet temp = p[j];
                   p [j] = p[j+1];
                   p[j+1] = temp;
               }
           }
       }
   }

    @Override
    public Object find(Object o) {


            Pet a = (Pet) o;
            for (int i = 0; i < size; i++) {
                if (a.equals(p[i])) {
                    //System.out.println("666");
                    return p[i];
                }
            }



        return  null;

    }
}
