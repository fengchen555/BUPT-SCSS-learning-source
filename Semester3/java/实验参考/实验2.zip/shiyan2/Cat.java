public class Cat extends Pet{
    private String side;
    double moneySum = 0;
    int count = 0;
    public Cat(String pname, String oname, double wt) {
        super(pname, oname, wt);
        this.side = "inside";


    }
    public  void goOutside(){
        side = "outside";
    }

    @Override
    public String toString() {

        return side+" cat "+super.toString();
    }

    @Override
    public double visit(int shots) {
        count++;
        if(side == "inside") {
            moneySum += 20 + super.visit(shots);
            return 20 + super.visit(shots);
        }
        else {
            moneySum += 20 + super.visit(shots+1);
            return 20 + super.visit(shots + 1);
        }
    }

    @Override
    public double avgCost() {
        if(count == 0) return 0;
        return moneySum/count;
    }
}
